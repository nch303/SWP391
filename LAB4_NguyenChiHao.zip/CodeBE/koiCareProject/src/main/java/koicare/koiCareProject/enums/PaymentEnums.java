package koicare.koiCareProject.enums;

public enum PaymentEnums {
    BANKING,
    CASH
}
