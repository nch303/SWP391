package koicare.koiCareProject.dto.response;

import lombok.Data;

@Data
public class ProductTypeResponse {

    private long productTypeID;
    private String productTypeName;
}
