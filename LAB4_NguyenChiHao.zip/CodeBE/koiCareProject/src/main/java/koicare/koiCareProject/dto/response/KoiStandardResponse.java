package koicare.koiCareProject.dto.response;

import lombok.Data;

@Data
public class KoiStandardResponse {
    private double lowLength;
    private double hiLength;
    private double lowWeigh;
    private double hiWeight;
}
