package koicare.koiCareProject.dto.response;

import lombok.Data;

@Data

public class KoiVarietyResponse {

    private long koiVarietyID;
    private String varietyName;

}
