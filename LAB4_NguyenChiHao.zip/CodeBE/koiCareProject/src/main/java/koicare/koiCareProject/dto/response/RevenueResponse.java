package koicare.koiCareProject.dto.response;

import lombok.Data;

@Data
public class RevenueResponse {
    private int month;
    private int year;
    private float revenue;
}
