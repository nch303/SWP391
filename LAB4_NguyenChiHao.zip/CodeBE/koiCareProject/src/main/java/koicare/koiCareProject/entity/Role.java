package koicare.koiCareProject.entity;

public enum Role {
    MEMBER,
    SHOP,
    ADMIN
}
