package koicare.koiCareProject.dto.response;

import lombok.Data;

@Data
public class KoiStatusResponse {

    private long koiStatusID;
    private String statusContent;

}
