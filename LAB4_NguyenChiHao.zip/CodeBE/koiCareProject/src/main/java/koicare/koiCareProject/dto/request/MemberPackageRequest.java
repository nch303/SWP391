package koicare.koiCareProject.dto.request;

import lombok.Data;

@Data
public class MemberPackageRequest {

    private int duration;
    private double price;
}
