package koicare.koiCareProject.enums;

public enum TransactionsEnum {
    SUCCESS,
    FAIL
}
