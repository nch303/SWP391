package koicare.koiCareProject.dto.request;

import lombok.Data;

@Data
public class ProductTypeRequest {

    private String productTypeName;
}
