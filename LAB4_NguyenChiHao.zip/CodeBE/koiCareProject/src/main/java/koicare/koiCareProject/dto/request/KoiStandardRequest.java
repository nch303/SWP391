package koicare.koiCareProject.dto.request;

import lombok.Data;

import java.util.Date;

@Data
public class KoiStandardRequest {

    private Date date;
    private long koiFishID;
}
