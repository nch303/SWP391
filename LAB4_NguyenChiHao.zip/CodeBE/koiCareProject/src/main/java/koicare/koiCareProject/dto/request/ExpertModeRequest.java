package koicare.koiCareProject.dto.request;

import lombok.Data;

@Data
public class ExpertModeRequest {
    private int pondID;
    private double percent;
}
