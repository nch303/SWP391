package koicare.koiCareProject.dto.request;

import lombok.Data;

import java.util.UUID;

@Data
public class OrderDetailRequest {
    private UUID packageID;

}
