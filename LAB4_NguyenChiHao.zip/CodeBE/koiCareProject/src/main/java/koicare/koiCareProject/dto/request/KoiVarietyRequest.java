package koicare.koiCareProject.dto.request;

import lombok.Data;

@Data
public class KoiVarietyRequest {

    private String varietyName;

}
