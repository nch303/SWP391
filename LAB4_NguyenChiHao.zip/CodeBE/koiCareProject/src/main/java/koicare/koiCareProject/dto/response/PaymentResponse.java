package koicare.koiCareProject.dto.response;

import lombok.Data;

@Data
public class PaymentResponse {

    private Long paymentID;
    private String paymentType;
}
